// BankAccount class represents a simple bank account
class BankAccount {
    // Private attributes to store account details
    private String accNumber;   // Account number
    private String accHolder;   // Account owner's name
    private double accBalance;  // Current account balance

    // Constructor to initialize account details
    public BankAccount(String accNumber, String accHolder, double accBalance) {
        this.accNumber = accNumber;
        this.accHolder = accHolder;
        this.accBalance = accBalance;
    }

    // Method to display account details
    public void showDetails() {
        System.out.println("Account No: " + accNumber);
        System.out.println("Holder: " + accHolder);
        System.out.println("Balance: $" + accBalance);
        System.out.println("--------------------------");
    }

    // Method to deposit money into the account
    public void addFunds(double amount) {
        if (amount > 0) { // Check if the deposit amount is valid
            accBalance += amount; // Add the amount to the balance
            System.out.println(accHolder + " added $" + amount);
            System.out.println("Updated Balance: $" + accBalance);
        } else {
            System.out.println("Invalid deposit amount!"); // Display an error for negative deposits
        }
        System.out.println("--------------------------");
    }

    // Method to withdraw money from the account
    public void takeOutMoney(double amount) {
        if (amount > 0 && amount <= accBalance) { // Check if the withdrawal amount is valid
            accBalance -= amount; // Deduct the amount from the balance
            System.out.println(accHolder + " withdrew $" + amount);
            System.out.println("Remaining Balance: $" + accBalance);
        } else if (amount > accBalance) { // If the balance is insufficient
            System.out.println("Not enough balance!");
        } else { // If the amount is invalid (negative)
            System.out.println("Invalid withdrawal amount!");
        }
        System.out.println("--------------------------");
    }
}

// Main class to execute the program
public class Main {
    public static void main(String[] args) {
        // Creating two bank accounts with initial values
        BankAccount acc1 = new BankAccount("ID123456", "John Doe", 750.00);
        BankAccount acc2 = new BankAccount("ID987654", "Jane Smith", 300.00);

        // Display initial account details
        acc1.showDetails();
        acc2.showDetails();

        // Perform transactions: deposit money into acc1 and withdraw from acc2
        acc1.addFunds(150);  // Depositing money into acc1
        acc2.takeOutMoney(50); // Withdrawing money from acc2

        // Display account details after transactions
        acc1.showDetails();
        acc2.showDetails();
    }
}
