import java.util.Scanner;

// Admin class
class Admin {
    private String username = "admin";
    private String password = "admin123";

    public boolean login(String inputUsername, String inputPassword) {
        return username.equals(inputUsername) && password.equals(inputPassword);
    }
}

// Student class
class Student {
    private String name;
    private String studentID;

    public Student(String name, String studentID) {
        this.name = name;
        this.studentID = studentID;
    }

    public boolean login(String inputName, String inputStudentID) {
        return name.equals(inputName) && studentID.equals(inputStudentID);
    }

    public void displayInfo() {
        System.out.println("Login successful!");
        System.out.println("Student Name: " + name);
        System.out.println("Student ID: " + studentID);
    }
}

// Main LoginSystem class
  class LoginSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Admin admin = new Admin();
        Student student = new Student("John Doe", "S12345"); // Sample student

        System.out.println("Choose login type:");
        System.out.println("1. Admin");
        System.out.println("2. Student");
        System.out.print("Enter choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter admin username: ");
                String adminUsername = scanner.nextLine();
                System.out.print("Enter admin password: ");
                String adminPassword = scanner.nextLine();
                if (admin.login(adminUsername, adminPassword)) {
                    System.out.println("Admin login successful!");
                } else {
                    System.out.println("Invalid admin credentials!");
                }
                break;

            case 2:
                System.out.print("Enter student name: ");
                String studentName = scanner.nextLine();
                System.out.print("Enter student ID: ");
                String studentID = scanner.nextLine();
                if (student.login(studentName, studentID)) {
                    student.displayInfo();
                } else {
                    System.out.println("Invalid student credentials!");
                }
                break;

            default:
                System.out.println("Invalid choice! Please select 1 or 2.");
        }

        scanner.close();
    }
}
