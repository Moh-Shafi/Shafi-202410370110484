import java.util.Scanner;
import java.time.LocalDate;

class UserDetails {
    public static void main(String[] args) {
        // ایجاد Scanner برای دریافت ورودی از کاربر
        Scanner scanner = new Scanner(System.in);

        // دریافت نام کاربر
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        // دریافت جنسیت کاربر
        System.out.print("Enter your gender (M/F): ");
        char genderChar = scanner.next().charAt(0);
        String gender;

        if (genderChar == 'M' || genderChar == 'm') {
            gender = "Male";
        } else if (genderChar == 'F' || genderChar == 'f') {
            gender = "Female";
        } else {
            gender = "Unknown";
        }

        // دریافت سال تولد کاربر
        System.out.print("Enter your year of birth: ");
        int yearOfBirth = scanner.nextInt();

        // محاسبه سن
        int currentYear = LocalDate.now().getYear();
        int age = currentYear - yearOfBirth;

        // بستن Scanner
        scanner.close();

        // نمایش اطلاعات کاربر
        System.out.println("\nUser Details:");
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
        System.out.println("Age: " + age);
    }
}
