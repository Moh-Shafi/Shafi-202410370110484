package com.example.loginapp;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etStudentName, etStudentID;
    private TextView tvResult;
    private RadioButton rbAdmin, rbStudent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ارتباط با المان‌های UI
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        rbAdmin = findViewById(R.id.rbAdmin);
        rbStudent = findViewById(R.id.rbStudent);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etStudentName = findViewById(R.id.etStudentName);
        etStudentID = findViewById(R.id.etStudentID);
        Button btnLogin = findViewById(R.id.btnLogin);
        tvResult = findViewById(R.id.tvResult);

        // تغییر فیلدهای ورودی بر اساس انتخاب کاربر
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbAdmin) {
                etUsername.setVisibility(View.VISIBLE);
                etPassword.setVisibility(View.VISIBLE);
                etStudentName.setVisibility(View.GONE);
                etStudentID.setVisibility(View.GONE);
            } else if (checkedId == R.id.rbStudent) {
                etUsername.setVisibility(View.GONE);
                etPassword.setVisibility(View.GONE);
                etStudentName.setVisibility(View.VISIBLE);
                etStudentID.setVisibility(View.VISIBLE);
            }
        });

        // دکمه ورود
        btnLogin.setOnClickListener(view -> login());
    }

    private void login() {
        if (rbAdmin.isChecked()) {
            String username = etUsername.getText().toString();
            String password = etPassword.getText().toString();
            String lastThreeDigits = "069"; // تغییر به مقدار دلخواه
            String validUsername = "Admin" + lastThreeDigits;
            String validPassword = "Password" + lastThreeDigits;

            if (username.equals(validUsername) && password.equals(validPassword)) {
                tvResult.setText("Admin login successful!");
            } else {
                tvResult.setText("Login failed! Wrong username or password.");
            }
        } else if (rbStudent.isChecked()) {
            String name = etStudentName.getText().toString();
            String studentID = etStudentID.getText().toString();
            String validName = "Ken Aryo Bimantoro";
            String validStudentID = "202310370311006";

            if (name.equals(validName) && studentID.equals(validStudentID)) {
                tvResult.setText("Student Login Successful!\nName: " + name + "\nStudent ID: " + studentID);
            } else {
                tvResult.setText("Login Failed! Wrong name or student ID.");
            }
        } else {
            tvResult.setText("Please select a login type.");
        }
    }
}
