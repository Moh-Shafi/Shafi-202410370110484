import java.util.Scanner;

// کلاس پایه برای لاگین - این کلاس انتزاعی است و به عنوان یک الگو برای کلاس‌های دیگر استفاده می‌شود
abstract class UserLogin {
    protected Scanner scanner; // تعریف یک Scanner برای دریافت ورودی از کاربر

    // سازنده کلاس که یک Scanner را دریافت می‌کند
    public UserLogin(Scanner scanner) {
        this.scanner = scanner;
    }

    // متد انتزاعی login که کلاس‌های فرزند باید آن را پیاده‌سازی کنند
    public abstract void login();
}

// کلاس AdminLogin که از UserLogin ارث‌بری می‌کند
class AdminLogin extends UserLogin {
    private final String lastThreeDigits; // سه رقم آخر برای تأیید اعتبار ادمین

    // سازنده کلاس که مقدار سه رقم آخر را دریافت می‌کند
    public AdminLogin(Scanner scanner, String lastThreeDigits) {
        super(scanner); // ارسال Scanner به کلاس والد
        this.lastThreeDigits = lastThreeDigits;
    }

    // پیاده‌سازی متد login برای ادمین
    @Override
    public void login() {
        System.out.print("Enter Admin Username: ");
        String username = scanner.nextLine(); // دریافت نام کاربری

        System.out.print("Enter Admin Password: ");
        String password = scanner.nextLine(); // دریافت رمز عبور

        // ایجاد نام کاربری و رمز عبور معتبر با استفاده از سه رقم آخر
        String validUsername = "Admin" + lastThreeDigits;
        String validPassword = "Password" + lastThreeDigits;

        // بررسی تطابق اطلاعات ورودی با مقادیر معتبر
        if (username.equals(validUsername) && password.equals(validPassword)) {
            System.out.println("✅ Admin login successful!");
        } else {
            System.out.println("❌ Login failed! Wrong username or password.");
        }
    }
}

// کلاس StudentLogin که از UserLogin ارث‌بری می‌کند
class StudentLogin extends UserLogin {
    private final String validName; // نام معتبر دانشجو
    private final String validID;   // شماره دانشجویی معتبر

    // سازنده کلاس که نام و شماره دانشجویی معتبر را دریافت می‌کند
    public StudentLogin(Scanner scanner, String validName, String validID) {
        super(scanner); // ارسال Scanner به کلاس والد
        this.validName = validName;
        this.validID = validID;
    }

    // پیاده‌سازی متد login برای دانشجو
    @Override
    public void login() {
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine(); // دریافت نام دانشجو

        System.out.print("Enter Student ID: ");
        String studentID = scanner.nextLine(); // دریافت شماره دانشجویی

        // بررسی تطابق اطلاعات ورودی با مقادیر معتبر
        if (name.equals(validName) && studentID.equals(validID)) {
            System.out.println("✅ Student Login Successful!");
            System.out.println("📌 Name: " + name);
            System.out.println("🎓 Student ID: " + studentID);
        } else {
            System.out.println("❌ Login Failed! Wrong name or student ID.");
        }
    }
}

// کلاس اصلی که مدیریت لاگین را انجام می‌دهد
class LoginSystem {
    // اطلاعات از پیش تعریف‌شده برای یک دانشجو و ادمین
    private static final String STUDENT_NAME = "Ken Aryo Bimantoro";
    private static final String STUDENT_ID = "202310370311006";
    private static final String LAST_THREE_DIGITS = "006"; // سه رقم آخر شماره دانشجویی برای ورود ادمین

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // ایجاد Scanner برای دریافت ورودی از کاربر

        // نمایش منوی انتخاب نوع ورود
        System.out.println("🔐 Select Login Type:");
        System.out.println("1️⃣ Admin");
        System.out.println("2️⃣ Student");
        System.out.print("Enter your choice: ");

        try {
            int choice = Integer.parseInt(scanner.nextLine()); // خواندن انتخاب کاربر و تبدیل آن به عدد

            // استفاده از switch برای پردازش انتخاب کاربر
            switch (choice) {
                case 1 -> new AdminLogin(scanner, LAST_THREE_DIGITS).login(); // ورود به عنوان ادمین
                case 2 -> new StudentLogin(scanner, STUDENT_NAME, STUDENT_ID).login(); // ورود به عنوان دانشجو
                default -> System.out.println("⚠️ Invalid choice."); // در صورت انتخاب عدد نامعتبر
            }
        } catch (NumberFormatException e) {
            System.out.println("⚠️ Invalid input. Please enter a number."); // مدیریت ورودی‌های غیر عددی
        } finally {
            scanner.close(); // جلوگیری از نشت حافظه با بستن Scanner
        }
    }
}
