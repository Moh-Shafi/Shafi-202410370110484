class GameCharacter {
    // Base class for all characters in the game
    private String name;
    private int health;

    // Constructor to initialize character's name and health
    public GameCharacter(String name, int health) {
        this.name = name;
        this.health = health;
    }

    // Getter method to retrieve the character's name
    public String getName() {
        return name;
    }

    // Getter method to retrieve the character's health
    public int getHealth() {
        return health;
    }

    // Setter method to update the character's health
    public void setHealth(int health) {
        this.health = health;
    }

    // Attack method to be overridden by subclasses
    public void attack(GameCharacter target) {
        // This method will be overridden in subclasses
    }
}

class Hero extends GameCharacter {
    // Constructor for the Hero class, calls the superclass constructor
    public Hero(String name, int health) {
        super(name, health);
    }

    // Overriding the attack method for Hero
    @Override
    public void attack(GameCharacter target) {
        System.out.println(getName() + " attacks " + target.getName() + " using Orbital Strike!");
        target.setHealth(target.getHealth() - 20); // Reducing target's health by 20
        System.out.println(target.getName() + " now has " + target.getHealth() + " health.\n");
    }
}

class Enemy extends GameCharacter {
    // Constructor for the Enemy class, calls the superclass constructor
    public Enemy(String name, int health) {
        super(name, health);
    }

    // Overriding the attack method for Enemy
    @Override
    public void attack(GameCharacter target) {
        System.out.println(getName() + " attacks " + target.getName() + " using Snake Bite!");
        target.setHealth(target.getHealth() - 15); // Reducing target's health by 15
        System.out.println(target.getName() + " now has " + target.getHealth() + " health.\n");
    }
}

public class Main {
    public static void main(String[] args) {
        // Creating a general character (not actively used in combat)
        GameCharacter generalCharacter = new GameCharacter("General Character", 100);

        // Creating the Hero and Enemy objects with their initial health values
        Hero brimstone = new Hero("Brimstone", 150);
        Enemy viper = new Enemy("Viper", 200);

        // Displaying the initial health of the Hero and Enemy
        System.out.println("Initial status:\n");
        System.out.println(brimstone.getName() + " has health: " + brimstone.getHealth());
        System.out.println(viper.getName() + " has health: " + viper.getHealth() + "\n");

        // Simulating the battle sequence
        brimstone.attack(viper); // Brimstone attacks Viper
        brimstone.attack(viper); // Brimstone attacks again
        viper.attack(brimstone); // Viper counterattacks
    }
}