import java.util.Scanner;

// Superclass: User
class User {
    private String name;
    private String studentID;

    public User(String name, String studentID) {
        this.name = name;
        this.studentID = studentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public boolean login(String inputName, String inputID) {
        return false; // To be overridden by subclasses
    }

    public void displayInfo() {
        System.out.println("User Info: " + name + ", ID: " + studentID);
    }
}

// Subclass: Admin
class Admin extends User {
    private String username;
    private String password;

    public Admin(String name, String studentID, String username, String password) {
        super(name, studentID);
        this.username = username;
        this.password = password;
    }

    @Override
    public boolean login(String inputUsername, String inputPassword) {
        return inputUsername.equals(this.username) && inputPassword.equals(this.password);
    }

    @Override
    public void displayInfo() {
        System.out.println("Admin Login Successful: " + getName());
    }
}

// Subclass: Student
class Student extends User {
    public Student(String name, String studentID) {
        super(name, studentID);
    }

    @Override
    public boolean login(String inputName, String inputID) {
        return inputName.equals(getName()) && inputID.equals(getStudentID());
    }

    @Override
    public void displayInfo() {
        System.out.println("Student Login Successful: " + getName());
    }
}

// Main Program: LoginSystem
class LoginSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Admin admin = new Admin("Admin User", "0001", "admin", "password123");
        Student student = new Student("John Doe", "S12345");

        System.out.println("Select login type: 1. Admin  2. Student");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (choice == 1) {
            System.out.print("Enter Username: ");
            String username = scanner.nextLine();
            System.out.print("Enter Password: ");
            String password = scanner.nextLine();

            if (admin.login(username, password)) {
                admin.displayInfo();
            } else {
                System.out.println("Invalid Admin credentials!");
            }
        } else if (choice == 2) {
            System.out.print("Enter Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Student ID: ");
            String studentID = scanner.nextLine();

            if (student.login(name, studentID)) {
                student.displayInfo();
            } else {
                System.out.println("Invalid Student credentials!");
            }
        } else {
            System.out.println("Invalid choice!");
        }

        scanner.close();
    }
}
